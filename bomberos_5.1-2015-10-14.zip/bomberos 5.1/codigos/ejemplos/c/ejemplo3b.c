 #include <stdio.h>

int main (void)
{
 int Entero;
 Entero=10;
return 0;
}
