/*Importación de funciones, variables, constantes, etc.

Definición de constantes y macros.

Definición de nuevos tipos de datos.

Declaración de variables globales.

Definición de funciones.*/

int main (void)

{

//Declración de variables propias del programa principal (o sea, locales a main).

//Programa principal.

return 0;

}
