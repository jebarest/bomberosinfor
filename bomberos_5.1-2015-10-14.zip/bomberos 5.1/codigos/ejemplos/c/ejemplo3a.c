#include <stdio.h>

int main (void)

{

//Declaramos el tipo de dato más el nombre del dato.

int Entero;

//Asignamos valores a el tipo de dato anteriormente declarado.

Entero=10;

return 0;

}
