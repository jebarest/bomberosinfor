#include <stdio.h>

int main (void)
{
	/*Programa principal*/
return 0;
}
