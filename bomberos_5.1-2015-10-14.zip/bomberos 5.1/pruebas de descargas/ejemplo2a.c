/************************************
*Un programa de ejemplo.
*---------------------------------------------------------
*Propósito: mostrar algunos efectos que se pueden lograr con
*comentarios de C
*************************************/
#include <stdio.h>

/*-------------------------------------------------------
*Programa principal
int main (void){


return 0;
}
*--------------------------------------------------------*/
